package frc.robot;

import edu.wpi.first.wpilibj.RobotBase;

/**
 * This class defines the runtime mode used by AdvantageKit. The mode is always "real" when running
 * on a roboRIO. Change the value of "simMode" to switch between "sim" (physics sim) and "replay"
 * (log replay from a file).
 */
public final class Constants {
  public static final boolean kTuningMode = true;

  public static final Mode kSimMode = Mode.SIM;
  public static final Mode kCurrentMode = RobotBase.isReal() ? Mode.REAL : kSimMode;

  public class DriveConstants {
    public static final double kRotationVoltage = 6.0;
    public static final double kMovementVoltage = 12.0;

    public static final double kMaxLinearSpeed = 3.0; // meters per second
    public static final double kTeleopRotationSpeed = 10.0;

    public static final double kCurrentLimit = 60.0;

    public static final double kMaxInput = 0.5;
  }

  public class Ports {
    public static final int kLFPort = 1;
    public static final int kLRPort = 2;
    public static final int KRFPort = 4;
    public static final int kRRPort = 3;

    public static final double kRollerPort = 5;
  }

  public class RollerConstants {
    public static final double kRollerSpeed = 5.0;
  }

  public static enum Mode {
    /** Running on a real robot. */
    REAL,

    /** Running a physics simulator. */
    SIM,

    /** Replaying from a log file. */
    REPLAY
  }
}
